        <?php include "includes/db.php"; ?> 
        <?php include "includes/header.php"; ?> 
        
        <?php include "includes/navigation.php"; ?> 

           <div class="card text-white">
              <img class="card-img" src="resources/img/watbridge-reception.jpg" alt="">
              <div class="card-img-overlay">
                  <h4 class="card-title">Welcome to Our Facility</h4>
                  <p class="card-text">Scroll down to take a tour</p>
              </div>
              <p class="text-muted text-center"><small>Click on the picture to zoom, then click outside to return to normal</small></p>
          </div>

          <section class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="row mb-4">
                    <a href="resources/img/watbridge-front-view.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4">
                        <img src="resources/img/watbridge-front-view.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                        <figcaption class="text-danger">Our front view</figcaption>
                    </a>
                    <a href="resources/img/watbridge-front-night.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4">
                        <img src="resources/img/watbridge-front-night.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                    </a>
                    <a href="resources/img/watbridge-gym.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4">
                        <img src="resources/img/watbridge-gym.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                        <figcaption class="text-danger">Muhammad Ali Gym</figcaption>
                    </a>
                </div>

                <div class="row mb-4">
                    <a href="resources/img/watbridge-laundry.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-3">
                        <img src="resources/img/watbridge-laundry.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                    </a>
                    <a href="resources/img/watbridge-poolside.jpg" data-toggle="lightbox"  data-gallery="example-gallery" class="col-sm-3">
                        <img src="resources/img/watbridge-poolside.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                        <figcaption class="text-danger">Super Poolside</figcaption>
                    </a>
                    <a href="resources/img/watbridge-restaurant.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-3">
                        <img src="resources/img/watbridge-restaurant.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                        <figcaption class="text-danger">Restaurant</figcaption>
                    </a>
                    <a href="resources/img/watbridge-snacksbar.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-3">
                      <img src="resources/img/watbridge-snacksbar.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                      <figcaption class="text-danger">Snacks and Coffee Bar</figcaption>
                  </a>
                </div>

                <div class="row mb-4">
                  <a href="resources/img/watbridge-shakespear.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4">
                      <img src="resources/img/watbridge-shakespear.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See"> 
                      <figcaption class="text-danger">Shakespeare Room</figcaption>
                  </a>
                  <a href="resources/img/watbridge-village-square.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4">
                      <img src="resources/img/watbridge-village-square.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                      <figcaption class="text-danger">Village Square</figcaption>
                  </a>
                  <a href="resources/img/watbridge-club.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4">
                      <img src="resources/img/watbridge-club.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                      <figcaption class="text-danger">Our Lounge</figcaption>
                  </a>
              </div>

              <div class="row mb-4">
                <a href="resources/img/watbridge-hall1.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-3">
                    <img src="resources/img/watbridge-hall1.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                    <figcaption class="text-danger">Nelson Mandela Banquet Hall</figcaption>
                </a>
                <a href="resources/img/watbridge-poolside.jpg" data-toggle="lightbox"  data-gallery="example-gallery" class="col-sm-3">
                    <img src="resources/img/watbridge-poolside.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                </a>
                <a href="resources/img/watbridge-restaurant.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-3">
                    <img src="resources/img/watbridge-restaurant.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                </a>
                <a href="resources/img/watbridge-snacksbar.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-3">
                  <img src="resources/img/watbridge-snacksbar.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
              </a>
            </div>


            </div>
        </div>
      </section>


<?php include "includes/footer.php"; ?> 