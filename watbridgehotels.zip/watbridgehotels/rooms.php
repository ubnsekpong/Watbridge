        <?php include "includes/db.php"; ?> 
        <?php include "includes/header.php"; ?> 
        
        <?php include "includes/navigation.php"; ?> 

            <header id="page-header">
              <div class="container">
                <div class="row">
                  <div class="col-md-6 m-auto text-center">
                    <h3>Check Out Our Rooms</h3>
                    <p class="header-text">... Best Comfort at affordable prices</p>
                  </div>
                </div>
              </div>
            </header>

            <div class="container">
              <div class="row mt-4 facility">
                  <div class="card-columns">
                  <div class="card">
                      <img class="card-image-top img-fluid" src="resources/img/watbridge-classic.jpg" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502" alt="watbridge classic room">
                      <div class="card-body">
                          <h4 class="card-title text-danger text-center">Classic Room</h4>
                          <span class="btn btn-dark btn-block"><p class="card-text btn btn-primary btn-small text-light">Price: 15,000.00</p><div class="text-light" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502 Email: booking@watbridgehotels.com">Click Here</div></span> 
                        </div>
                  </div>
                  
                  <div class="card">
                      <img class="card-image-top img-fluid" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502" alt="watbridge classic room" src="resources/img/watbridge-deluxe-room.jpg" alt="Watbridge Deluxe Room">
                      <div class="card-body">
                        <h4 class="card-title text-danger text-center">Deluxe Room</h4>
                        <span class="btn btn-dark btn-block"><p class="card-text btn btn-primary btn-small text-light">Price: 20,000.00</p><div class="text-light" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502 Email: booking@watbridgehotels.com">Click Here</div></span> 
                      </div>
                  </div>
                  
                  <div class="card">
                      <img class="card-image-top img-fluid" src="resources/img/watbridge-executive-suite.jpg" alt="Watbridge Executive Room" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502">
                      <div class="card-body">
                        <h4 class="card-title text-danger text-center">Executive Room</h4>
                        <span class="btn btn-dark btn-block"><p class="card-text btn btn-primary btn-small text-light">Price: 25,000.00</p><div class="text-light" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502 Email: booking@watbridgehotels.com">Click Here</div></span> 
                      </div>
                  </div>
              </div>
              </div>
                </div>

                <div class="container">
                  <div class="row mt-4 facility">
                      <div class="card-columns">
                      <div class="card">
                          <img class="card-image-top img-fluid" src="resources/img/watbridge-diplomatic-room.jpg" alt="Watbridge Diplomatic Room" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502">
                          <div class="card-body">
                              <h4 class="card-title text-danger text-center">Diplomatic Room</h4>
                              <span class="btn btn-dark btn-block"><p class="card-text btn btn-primary btn-small text-light">Price: 30,000.00</p><div class="text-light" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502 Email: booking@watbridgehotels.com">Click Here</div></span> 
                            </div> 
                            </div>
                      
                      
                      <div class="card">
                          <img class="card-image-top img-fluid" src="resources/img/watbridge-royal-suite.jpg" alt="Watbridge Royal Suite" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502">
                         <div class="card-body">
                            <h4 class="card-title text-danger text-center">Royal Suite</h4>
                            <span class="btn btn-dark btn-block"><p class="card-text btn btn-primary btn-small text-light">Price: 35,000.00</p><div class="text-light" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502 Email: booking@watbridgehotels.com">Click Here</div></span> 
                          </div>
                      </div>
                   
                      
                      <div class="card">
                          <img class="card-image-top img-fluid" src="resources/img/watbridge-emperor-suite.jpg" alt="Watbridge Emperor Suite" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502">
                          <div class="card-body">
                            <h4 class="card-title text-danger text-center"> Emperor Suite</h4>
                            <span class="btn btn-dark btn-block"><p class="card-text btn btn-primary btn-small text-light">Price: 50,000.00</p><div class="text-light" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502 Email: booking@watbridgehotels.com">Click Here</div></span> 
                          </div>
                      </div>
                  </div>
                  </div>
                    </div>


                    <div class="container">
                        <div class="row mt-4 facility">
                            <div class="card-columns">
                            <div class="card">
                                <img class="card-image-top img-fluid" src="resources/img/watbridge-emperor-masterly.jpg" alt="watbridge emperor majesty" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502">
                                <div class="card-body">
                                    <h4 class="card-title text-danger text-center">Emperor-Majesty Suite</h4>
                                    <span class="btn btn-dark btn-block"><p class="card-text btn btn-primary btn-small text-light">Price: 60,000.00</p><div class="text-light" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502 Email: booking@watbridgehotels.com">Click Here</div></span> 
                                  </div>
                            </div>
                            
                            <div class="card">
                               <img class="card-image-top img-fluid" src="resources/img/watbridge-presidential.jpg" alt="Watbridge Presidential Suite" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502">
                                <div class="card-body">
                                  <h4 class="card-title text-danger text-center">Presidential Suite with Kitchenette</h4>
                                  <span class="btn btn-dark btn-block"><p class="card-text btn btn-primary btn-small text-light">Price: 80,000.00</p><div class="text-light" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502 Email: booking@watbridgehotels.com">Click Here</div></span> 
                                </div>
                            </div>
                            
                            <div class="card">
                                <img class="card-image-top img-fluid" src="resources/img/watbridge-family-room.jpg" alt="Watbridge Family Room" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502">
                                <div class="card-body">
                                  <h4 class="card-title text-danger text-center">Family Rooms</h4>
                                  <span class="btn btn-dark btn-block"><p class="card-text btn btn-primary btn-small text-light">Price: 40,000.00</p><div class="text-light" data-toggle="popover" data-placement="top" data-content="Call the reception to secure this room now 09038151033, 09029328502 Email: booking@watbridgehotels.com">Click Here</div></span> 
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
        
                     <?php include "includes/footer.php"; ?> 