        <?php include "includes/db.php"; ?> 
        <?php include "includes/header.php"; ?> 
        
           
            <?php 

         
            if(isset($_POST['submit'])){
         
            $to         = "ubongnsekpong@gmail.com";
            $subject    = wordwrap($_POST['subject'], 70);
            $body       = $_POST['body'];
            $header     = "From: " . $_POST['email'];
                
            mail($to,$subject,$body, $header);

            }
    ?>

        
        
        <?php include "includes/navigation.php"; ?> 

            <header id="page-header">
              <div class="container">
                <div class="row">
                  <div class="col-md-6 m-auto text-center">
                    <h1 class="text-danger">You're a Call Away</h1>
                    <p class="header-text">Experience Comfort at its Peak</p>
                  </div>
                </div>
              </div>
            </header>
            
         
            <div class="container mt-3">
            <div div class="row">
                <div class="col-sm-6 col-md-4 bg-light mb-4">
                    <h4 class="text-center text-primary">You can Reach Us<hr></h4>
                    11A/B IBB Avenue<br>
                    Opposite Ibom Hall<br> 
                    Uyo - Akwa Ibom State<br> 
                    Nigeria<br> 
                    Email: watbridgehospitality@gmail.com<br> 
                    Phones: 09038151033, 09029328502<br>
                </div>

                <div class="col-sm-6 col-md-8">
                    <div class="text-center">
                            <h4 class="text-primary">We're happy to hear from you<hr></h4>
                        </div>
                        
                <div class="form-wrap mb-3">
                
                    <form role="form" action="" method="post" id="login-form" autocomplete="off">
                       
                         <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" name="email" id="email" class="form-control" placeholder="Your Email">
                        </div>
                        
                        <div class="form-group">
                            <label for="subject" class="sr-only">Subject</label>
                            <input type="text" name="subject" id="subject" class="form-control" placeholder="What's the Subject?">
                        </div>
                        
                         <div class="form-group">
                           <label for="body" class="sr-only">Your Message</label>
                            <textarea name="body" id="body" cols="50" rows="10" class="form-control" placeholder="Your Message Please"></textarea>
                        </div>
                
                        <input type="submit" name="submit" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Send">
                    </form>
                 
                </div>
                 
                </div>
              
              </div>
            </div>
            
        <?php include "includes/footer.php"; ?> 