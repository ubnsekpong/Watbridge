<?php


class Config {


    const SMTP_HOST = 'smtp.mailtrap.io';


    const SMTP_PORT = 2525;

    const SMTP_USER = '348fae495d025f';

    const SMTP_PASSWORD = 'db596a0a76000a';



}
