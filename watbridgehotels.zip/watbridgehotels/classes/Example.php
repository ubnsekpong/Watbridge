<?php 

    class Example {
        
        
        public function display(){
            
            echo "This is a method from class";
            
        }
    }




?>