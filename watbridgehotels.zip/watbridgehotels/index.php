   
        <?php include "includes/db.php"; ?> 
        <?php include "includes/header.php"; ?> 

        <?php include "includes/navigation.php"; ?> 
        
        <header>
            <div class="container">

            
            <div class="hero-text-box">
                <h1 class="animate__animated animate__heartBeat">Need a Great Hotel in Uyo, Nigeria?<br><p class="header-text text-primary">experience<span><img class="header-logo" src="resources/img/watbridge-logo-transparent.png" alt="watbridge hotels logo"></span></p> </h1> 
                <a class="btn btn-full js--scroll-to-plans btn-text btn-header" href="room.php">Our Rooms</a>
                
                <a class="btn js--scroll-to-start btn-text btn-full btn-header" href="facility.php">Tour Facility</a>
                <div class="title_message spaces">&nbsp</div>
                <div class="title_message spaces">&nbsp</div>
                <div class="title_message spaces">&nbsp</div>
              
                <div class="display-4 title_message">Spacious &nbsp <span class="display-4 separator">&nbsp Serene &nbsp</span><span class="display-4 separator"> &nbsp Luxurious</span></div>
            </div>
        </div>
        </header>
        
        
        <div class="container">
           <div class="row">
             
             <div class="col-md-4 mt-3 mb-3 pl-2">
                 <div class="text-danger text-center display-4 mb-4">About Us</div>
                <div class="bg-light p-3"> 
                <p class="text-justify"><strong>Watbridge Hotels and Suites</strong> is a <strong>leading</strong> hospitality and events outfit. </p>
                    
                    <p>Strategically located in the centre of town @ 11A/B IBB Avenue, opposite the famous Ibom Hall in Uyo, Akwa Ibom State, Watbridge is easier to access from Victor Attah International Airport. </p>
                    
                    <p>It is about three minutes from the Idongesit Nkanga Secretariat, State Police Headquarters, Ikot Akpan Abia, Ibom Plaza and a walk from the Ibom E-Library.   
                     
                 </p>
                 </div> 
              </div>
             
              <div class="col-md-8 mt-3">
                 <div class="text-primary text-center text-danger mb-4 display-4">Our Event Facilities</div>
                  <div class="row mb-4">
                  <a href="resources/img/watbridge-poolside.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4 mb-2">
                      <img src="resources/img/watbridge-poolside.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See"> 
                      <figcaption class="text-danger text-center">Super Poolside</figcaption>
                      <div class="btn btn btn-block btn-primary">150 Capacity</div>
                  </a>
                  <a href="resources/img/watbridge-hall1.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4 mb-2">
                      <img src="resources/img/watbridge-hall1.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                      <figcaption class="text-danger text-center">Mandela Banquet Hall</figcaption>
                      <div class="btn btn btn-block btn-primary">800 Capacity</div>
                  </a>
                  <a href="resources/img/watbridge-shakespear.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4 mb-2">
                      <img src="resources/img/watbridge-shakespear.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See"> 
                      <figcaption class="text-danger text-center">Shakespeare Room</figcaption>
                      <div class="btn btn btn-block btn-primary">60 Capacity</div>
                  </a>
                  
                 
              </div>
                
                  <div class="row mb-4">
                  
                   <a href="resources/img/watbridge-city-view.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4 mb-2">
                      <img src="resources/img/watbridge-city-view.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                      <figcaption class="text-danger text-center">Exotic City View Hall</figcaption>
                      <div class="title_message spaces">&nbsp</div>
                      <div class="title_message spaces">&nbsp</div>
                      <div class="btn btn btn-block btn-primary">80 Capacity</div>
                  </a>
                  
                  <a href="resources/img/watbridge-lugard-terrace.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4 mb-2">
                      <img src="resources/img/watbridge-lugard-terrace.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                      <figcaption class="text-danger text-center">Lugard Terrace</figcaption>
                      <div class="title_message spaces">&nbsp</div>
                      <div class="btn btn btn-block btn-primary">200 Capacity</div>
                  </a>
                  <a href="resources/img/watbridge-ngugi-wa-thiongo.jpg" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4 mb-2">
                      <img src="resources/img/watbridge-ngugi-wa-thiongo.jpg" class="img-fluid" data-toggle="tooltip" data-placement="top" title="Click to See">
                      <figcaption class="text-danger text-center">Ngugi Wa Thiongo Room and conference facility.</figcaption>
                      <div class="btn btn btn-block btn-primary">50 Capacity</div>
                  </a>
              </div>
                </div>
           
              
              
        </div>
</div>
        

        
        
        <div class="text-center js--section-features mt-5" id="features">
                    <h2 class="text-danger">Get it hot from our kitchen</h2>
                
        </div>
            
        
        <section class="section-meals">
            <ul class="meals-showcase">
                <li>
                    <figure class="meal-photo">
                        <img src="resources/img/1.jpg" alt="Korean bibimbap with egg and vegetables">
                    </figure>
                </li>
                <li>
                    <figure class="meal-photo">
                        <img src="resources/img/2.jpg" alt="Simple italian pizza with cherry tomatoes">
                    </figure>
                </li>
                <li>
                    <figure class="meal-photo">
                        <img src="resources/img/3.jpg" alt="Chicken breast steak with vegetables">
                    </figure>
                </li>
                <li>
                    <figure class="meal-photo">
                        <img src="resources/img/4.jpg" alt="Autumn pumpkin soup">
                    </figure>
                </li>
            </ul>
            <ul class="meals-showcase">
                <li>
                    <figure class="meal-photo">
                        <img src="resources/img/5.jpg" alt="Paleo beef steak with vegetables">
                    </figure>
                </li>
                <li>
                    <figure class="meal-photo">
                        <img src="resources/img/6.jpg" alt="Healthy baguette with egg and vegetables">
                    </figure>
                </li>
                <li>
                    <figure class="meal-photo">
                        <img src="resources/img/7.jpg" alt="Burger with cheddar and bacon">
                    </figure>
                </li>
                <li>
                    <figure class="meal-photo">
                        <img src="resources/img/8.jpg" alt="Granola with cherries and strawberries">
                    </figure>
                </li>
            </ul>
        </section>

<div>
        <p class="text-center text-danger mt-4 pt-4 display-3 life">Life has meaning...</p>
        <p class="text-center text-primary display-4">experience</p>
        <div class="d-flex justify-content-center">
        <img class="image-fluid"  style="max-width: 100%; height: auto;" src="resources/img/watbridge-logo-transparent.png" alt="Watbridge">
        
    </div>
    
</div>


<div class="card poolside">
    <img class="card-img-top" src="resources/img/watbridge-poolside.jpg" alt="watbridge poolside">
    <div class="card-body">
        <div class="mt-3">
            <h2 class="card-title text-center text-danger">Super Poolside</h2>
        </div>
        <p class="card-text text-danger text-center">*Adult and Children Poolside *Event venue *Gym *Drinks *Chops *Underground Nite Club *Village Square *Music (including live band)</p>
    </div>
</div>

<div class="container">
<div class="row mt-4 facility">
    <div class="card-columns">
    <div class="card">
      <a href="blog_post"><img class="card-image-top img-fluid" src="resources/img/watbridge-hall.jpg" alt="Blog posts"></a>
        <div class="card-body">
            <h4 class="card-title text-danger">Our Blogposts</h4>
            <p class="card-text">Check out our latest blog posts for events and happenings on <strong>The Bridge</strong></p>
            <div class="btn btn-primary btn-lg btn-block" ><a href="blog_post">Click Here</a></div>
        </div>
    </div>
    
    <div class="card">
        <a href="room.php"><img class="card-image-top img-fluid" src="resources/img/watbrige-rooms.jpg" alt=""></a>
        <div class="card-body">
            <h4 class="card-title text-danger">Check Out Our Rooms</h4>
            <p class="card-text">Classic, Exquisite, Watbridge offers the comfort you need away from your home</p>
            <div class="btn btn-primary btn-lg btn-block"><a href="room.php">Click Here</a></div>
        </div>
    </div>
    
    <div class="card">
        <a href="facility.php"><img class="card-image-top img-fluid" src="resources/img/watbridge-front.jpg" alt="Watbridge Facility"></a>
        <div class="card-body">
            <h4 class="card-title text-danger">Tour our Facility</h4>
            <p class="card-text">Here is a collection of pictures in a gallery where you can tour our facility.</p>
            <div class="btn btn-primary btn-lg btn-block"><a href="facility.php">Click Here</a></div>
        </div>
    </div>
    
    
    
    
</div>
</div>
  </div>
        
       
<?php include "includes/footer.php"; ?> 
 
