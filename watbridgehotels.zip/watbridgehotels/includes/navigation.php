    <nav class=" d-block bg-dark text-warning pb-0 text-center">        
        <marquee class="address" scrollamount="3">11A/B IBB Avenue, Opposite Ibom Hall, Uyo - Akwa Ibom State, Nigeria Email: watbridgehospitality@gmail.com Phones: 09038151033, 09029328502</marquee>
    </nav>
            
        

            <nav class="navbar navbar-expand-sm navbar-light bg-primary sticky-top pb-0 pt-0">
                <div class="container">
                    <a class="navbar-brand" href="/watbridgehotels"><img class="main-logo" src="/watbridgehotels/resources/img/watbridge-logo-transparent.png" alt="watbridge logo"> </a>
                    <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto">
                      
                    <!-- Adding category to navigation and active navigation-->
                      
                       <?php 
                        

//                        $query = "SELECT * FROM categories LIMIT 2";
//                        $select_all_categories_query = mysqli_query($connection,$query);
//
//                        while($row = mysqli_fetch_assoc($select_all_categories_query)) {
//                           $cat_title = $row['cat_title'];
//                           $cat_id = $row['cat_id'];
//                            
//                            $category_class = '';
//                            $registation_class = '';
//                            
//                            $pageName = basename($_SERVER['PHP_SELF']);
//                            $registration = 'registration.php';
//                            
//                            if(isset($_GET ['category']) && $_GET['category'] == $cat_id){
//                                
//                               
//                                $category_class = 'active';
//                                
//                                
//                            } else if($pageName = $registration){
//                                
//                                 $registation_class = 'active';
//                                
//                            }
//                                
                                
//                            echo "<li class ='nav-item $category_class'><a class='nav-link' href='category/category={$cat_id}'>{$cat_title}</a></li>";
//                        }

                        ?>
                       
                       
                       
                        <li class="nav-item">
                            <a class="nav-link active" href="/watbridgehotels/index">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/watbridgehotels/rooms">Our Rooms</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/watbridgehotels/facility">Our Facility</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/watbridgehotels/blog_post">Our Blog</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/watbridgehotels/contact">Contact</a>
                        </li>
                        
                        <li class='nav-item <?php echo $registration_class; ?>'>
                            <a class="nav-link" href="/watbridgehotels/registration">Register</a>
                        </li>
                        
                        <?php if(isLoggedIn()): ?>


                        <li>
                            <a class="nav-link" href="/watbridgehotels/admin">Admin</a>
                        </li>

                        <li>
                            <a class="nav-link" href="/watbridgehotels/includes/logout.php">Logout</a>
                        </li>


                    <?php else: ?>


                        <li>
                            <a class="nav-link" href="/watbridgehotels/login.php">Login</a>
                        </li>


                    <?php endif; ?>


                        <?php
                        
                        if(isset($_SESSION['user_role'])){
                            
                            if(isset($_GET['p_id'])){
                                
                                $the_post_id = $_GET['p_id'];
                                
                                
                                echo "<li class='nav-item'><a class='nav-link' href='/watbridgehotels/admin/posts.php?source=edit_post&p_id={$the_post_id}'>Edit Post</a></li>";
                                
                            }
                            
                        }
                    ?>
               </ul>
                    </div>
                </div>
            </nav>
