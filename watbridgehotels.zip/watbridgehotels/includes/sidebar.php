
<?php


        if(ifItIsMethod('post')){


                if(isset($_POST['login'])){


                    if(isset($_POST['username']) && isset($_POST['password'])){

                        login_user($_POST['username'], $_POST['password']);


                    }else {


                        redirect('index');
                    }


                }

        }

?>
                

         <div class="col-md-4 mt-3">
                <!-- Blog Search Well -->
                <div class="well">
                    <h4>Blog Search</h4>
                     <form action="search.php" method="post">
                    <div class="input-group">
                        <input name="search" type="text" class="form-control">
                        <span class="input-group-btn">
                            <button class="btn btn-default" name="submit" type="submit">
                                <span><i class="fa fa-search"></i></span>
                        </button>
                        </span>
                    </div>
                    </form>
                    <!-- /.input-group -->
                </div>
                
                  <!-- Login -->
                <div class="well">
                   
                   <?php if(isset($_SESSION['user_role'])): ?>
                       <h4>Logged in as <?php echo $_SESSION['username'] ?></h4>
                       
                       <a href="includes/logout.php" class="btn btn-success">Logout</a>
                   
                   <?php else: ?>
                   
                   <h4>Login</h4>
                     <form method="post">
                    <div class="form-group">
                        <input name="username" type="text" class="form-control" placeholder="Enter Username">
                    </div>
                    <div class="input-group">
                        <input name="password" type="password" class="form-control" placeholder="Enter Password">
                        <span class="input-group-btn">
                           <button class="btn btn-primary" name="login" type="submit">Submit
                           </button> 
                        </span>
                        
                    </div>
                    
                    <div class="blog-post form-group">

                        <a href="forgot.php?forgot=<?php echo uniqid(true); ?>">Forgot Password?</a>


                    </div>

                    
                    </form>
                   
                   <?php endif; ?>
                   
                   
                    </div>
                    <!-- /.input-group -->
                

        <!-- Blog Categories Well -->
        <div class="well">
            <?php

                $query = "SELECT * FROM categories"; 
                $select_categories_sidebar = mysqli_query($connection, $query);


           ?>


            <h4>Categories</h4>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="list-unstyled blog-post">
                      <a>

                       <?php

                    while($row = mysqli_fetch_assoc($select_categories_sidebar)) {
                    $cat_title = escape($row['cat_title']);
                    $cat_id = escape($row['cat_id']);

                    echo "<li><a href='/watbridgehotels/category/{$cat_id}'>{$cat_title}</a></li>";

                }
                 ?>
                       </a>
                    </ul>
            <!-- /.row -->
        </div>

                <!-- Side Widget Well -->
                
            </div>
            
    </div>
         
         <?php //include "includes/widget.php"; ?>
         
         
          <div class="card">
        <a href="rooms"><img class="card-image-top img-fluid" src="/watbridgehotels/resources/img/watbrige-rooms.jpg" alt=""></a>
        <div class="card-body">
            <h4 class="card-title text-danger">Check Out Our Rooms</h4>
            <p class="card-text">Classic, Exquisite, Watbridge offers the comfort you need away from your home</p>
            <div class="btn btn-primary btn-lg btn-block"><a href="rooms">Click Here</a></div>
        </div>
    </div>
    
    <div class="card">
        <a href="facility"><img class="card-image-top img-fluid" src="/watbridgehotels/resources/img/watbridge-front.jpg" alt="Watbridge Facility"></a>
        <div class="card-body">
            <h4 class="card-title text-danger">Tour our Facility</h4>
            <p class="card-text">Here is a collection of pictures in a gallery where you can tour our facility.</p>
            <div class="btn btn-primary btn-lg btn-block"><a href="facility">Click Here</a></div>
        </div>
    </div>
          
           
        