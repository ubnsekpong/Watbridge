 <footer class="bg-primary">
    <div class="row">
        <div class="col span-1-of-2">
            <ul class="footer-nav">
                <li><a href="index">Home</a></li>
                <li><a href="rooms">Our Rooms</a></li>
                <li><a href="facility">Facility Tour</a></li>
                <li><a href="blog_post">Our Blog</a></li>
                <li><a href="contact">Contact Us</a></li>
            </ul>
        </div>
        <div class="col span-1-of-2">
            <ul class="social-links">
                <li><a href="https://www.facebook.com/watbridgehotels/?ref=page_internal"><i class="ion-social-facebook"></i></a></li>
                <li><a href="#"><i class="ion-social-twitter"></i></a></li>
                <li><a href="#"><i class="ion-social-googleplus"></i></a></li>
                <li><a href="#"><i class="ion-social-instagram"></i></a></li>
            </ul>
        </div>
    </div>
    <div class="text-center">
        <p class="text-light">
            Copyright &copy; 2020 by Watbridge Hotels Uyo. All rights reserved.
        </p>
    </div>
</footer>
    
       <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
        crossorigin="anonymous"></script>
    <script src="resources/js/script.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.js"></script>

    <script>
      $(document).on('click', '[data-toggle="lightbox"]', function(event) {
                event.preventDefault();
                $(this).ekkoLightbox();
            });
    </script>
    
    <script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

      ga('create', 'UA-61026110-2', 'auto');
      ga('send', 'pageview');

    </script>
    
    <script>
            
                $('[data-toggle="popover"]').popover();
            
                function showPopover(){
            
                  $('#hello').popover('show');
            
                }
            
                function hidePopover(){
            
                $('#hello').popover('hide');
            
                }
            
                function togglePopover(){
            
                $('#hello').popover('toggle');
            
              }
            
              //Popover Events
            
              $('#hello').on('show.bs.popover', function() {
            
                console.log('popover show');
            
              });
            
              $('#hello').on('hide.bs.popover', function() {
            
            console.log('popover hide');
            
            });
            
            $('#hello').on('shown.bs.popover', function() {
            
            console.log('popover shown');

            popupWindow.setOutsideTouchable(true);
            popupWindow.setCancelable(true);
            
            });

              </script>

    </body>  
    
</html>