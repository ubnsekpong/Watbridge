<?php session_start(); ?>
<?php include "admin/functions.php"; ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Watbridge Hotels is a premium luxury hotel that can be rated among best hotels in Uyo, Akwa Ibom State">
        
        
        <link rel="stylesheet" type="text/css" href="/watbridgehotels/vendors/css/normalize.css">
        <link rel="stylesheet" type="text/css" href="/watbridgehotels/vendors/css/grid.css">
        <link rel="stylesheet" type="text/css" href="/watbridgehotels/vendors/css/ionicons.min.css">
        <link rel="stylesheet" type="text/css" href="/watbridgehotels/vendors/css/animate.css">
        <link rel="stylesheet" type="text/css" href="/watbridgehotels/resources/css/style.css"> 
        <link rel="stylesheet" type="text/css" href="/watbridgehotels/resources/css/blog_post.css">      
        <link rel="stylesheet" type="text/css" href="/watbridgehotels/resources/css/queries.css">
        <link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,300italic' rel='stylesheet' type='text/css'>

        <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400;500;600;700&display=swap" rel="stylesheet">

        <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
  />

        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
        
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
    
  
        <title>Watbridge Hotels Uyo</title>
        
        <link rel="apple-touch-icon" sizes="180x180" href="/watbridgehotels/resources/img/favicon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/watbridgehotels/resources/img/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/watbridgehotels/resources/img/favicon/favicon-16x16.png">
<link rel="manifest" href="/watbridgehotels/resources/img/favicon/site.webmanifest">
<link rel="mask-icon" href="/watbridgehotels/resources/img/favicon/safari-pinned-tab.svg">
<link rel="shortcut icon" href="/watbridgehotels/resources/img/favicon/favicon.ico">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="msapplication-config" content="/watbridgehotels/resources/img/favicon/browserconfig.xml">
<meta name="theme-color" content="#ffffff">
        
    </head>
    <body>
