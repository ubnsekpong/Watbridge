<?php  include "includes/db.php"; ?>
 <?php  include "includes/header.php"; ?>
 
 
 <?php

		checkIfUserIsLoggedInAndRedirect('/watbridgehotels/admin');


		if(ifItIsMethod('post')){

			if(isset($_POST['username']) && isset($_POST['password'])){

				login_user($_POST['username'], $_POST['password']);


			}else {


				redirect('/watbridgehotels/login');
			}

		}


?>


 


    <!-- Navigation -->
    
    <?php  include "includes/navigation.php"; ?>
    
 
    <!-- Page Content -->
    <div class="container">
    
    <section id="login">
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-md-6 col-xs-offset-3">
                <div class="form-wrap">
                 <h2 class="text-center">Login</h2>
                    <form role="form" action="" method="post" id="login-form" autocomplete="off">
                       
                        <div class="form-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fa fa-user"></i></span>
                            <input type="text" name="username" id="username" class="form-control" placeholder="Enter Username" autocomplete="on" value="">
                          </div>
                        </div>
                        
                        
                       
                        
                        
                         <div class="form-group">
                           <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fa fa-lock"></i></span>
                            <input type="password" name="password" id="key" class="form-control" placeholder="Enter Password">
                          </div>  
                        </div>
                
                        <input type="submit" name="register" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Login">
                    </form>
                 
                </div>
            </div> <!-- /.col-xs-12 -->
        </div> <!-- /.row -->
    </div> <!-- /.container -->
</section>

</div>
        <hr>



<?php include "includes/footer.php";?>
